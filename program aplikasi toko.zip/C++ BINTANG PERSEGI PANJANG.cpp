#include <iostream> // declare compiler input output
 using namespace std; //class std
 
int main() //main program tipe integer
{
  cout << "##  Program C++ Bintang Persegi Panjang  ##" << endl; //cetak program c++
  cout << "===========================================" << endl; //cetak == sebagai garis bawah kata yang di atasnya
  cout << endl; //break
 
  int tinggi_persegi,lebar_persegi,i,j; //memasukan variabel integer dengan variabel arr_count dan i  ( insilasi )
 
  cout << "Input tinggi persegi: "; //cetak kata tinggi persegi
  cin >> tinggi_persegi; //masukkan tinggi_persegi
  cout << "Input lebar persegi: "; //cetak kata lebar persegi
  cin >> lebar_persegi; // masukan lebar_persegi
 
  cout << endl; //break 
 
  for(i=1;i<=tinggi_persegi;i++) // data tinggi persegi itu hanya bisa di tampilkan dengan perulangan, i ini bertindak sebagai ( insilasi ) karna tinggi persegi itu ada indeks
  { 
    for(j=1;j<=lebar_persegi;j++) // data lebar persegi itu hanya bisa di tampilkan dengan perulangan, j ini bertindak sebagai ( insilasi ) karna lebar persegi itu ada indeks
{
    cout << " *"; // cetak bintang * 
}
    cout << endl; // break 
}
 
  return 0; // selesai
}
