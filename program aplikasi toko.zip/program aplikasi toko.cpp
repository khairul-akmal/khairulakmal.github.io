#include <iostream>

using namespace std;

int main(){
 int pilihan,totalPaket,banyak,hasil=0;
 char pilihanPaket,yesNo;
 int diskon = 10;
 int x=0;
 int totalSeluruhPesanan[x];
 
 cout<<"Kategori : "<<endl;
 cout<<"1. Fashion Muslim"<<endl;
 cout<<"2. Komputer & Aksesoris"<<endl;
 cout<<"3. Perlengkapan Rumah"<<endl;
 cout<<"4. Sepatu Pria"<<endl;
 cout<<"5. Kesehatan" <<endl;
 cout<<endl;
 
 do{
  cout<<"Masukan Kategori Yang Di Pilih : ";
  cin>>pilihan;
  
  switch(pilihan){
   case 1:
    cout<<"Fashion Muslim"<<endl;
    cout<<endl;
    
    cout<<"A. Hijab          	  : Rp.50.000,00"<<endl;
    cout<<"B. Kemeja Koko Pria	  : Rp.70.000,00"<<endl;
    cout<<"C. Peci		          : Rp.20.000,00"<<endl;
    cout<<"D. Gamis Wanita		  : Rp.100.000,00"<<endl;
    cout<<"E. Gamis Pria		  : Rp.120.000,00"<<endl;
    
    cout<<"Masukkan Pilihan  : ";
    cin>>pilihanPaket;
    
    if(pilihanPaket == 'A' || pilihanPaket == 'a'){
     totalPaket=50000;
    } else if(pilihanPaket == 'B' || pilihanPaket == 'b'){
     totalPaket=70000;
    } else if(pilihanPaket == 'C' || pilihanPaket == 'c'){
     totalPaket=20000;
    } else if(pilihanPaket == 'D' || pilihanPaket == 'd'){
     totalPaket=100000;
	} else if(pilihanPaket == 'E' || pilihanPaket == 'e'){
	 totalPaket=120000;
	
    } else {
     cout<<"Paket Tidak Tersedia"<<endl;
    }
    
    cout<<"Berapa Banyak Pesanan? ";
    cin>>banyak;
    
    totalSeluruhPesanan[x]=totalPaket*banyak;
    
    cout<<"Apakah Ada Pesanan Lainnya (Y/N)?";
    cin>>yesNo;
   
   break; 
    
   case 2:
    cout<<"Komputer & Aksesoris"<<endl;
    cout<<endl;
    
    cout<<"A. Monitor     : Rp.1.200.000,00"<<endl;
    cout<<"B. Keyboard    : Rp.200.000,00"<<endl;
    cout<<"C. CPU         : Rp.5.000.000,00"<<endl;
    cout<<"D. Printer     : Rp.2.000.000,00"<<endl;
    cout<<"E. Audio       : Rp.150.000,00"<<endl;
    
    cout<<"Masukkan Pilihan : ";
    cin>>pilihanPaket;;
    
    if(pilihanPaket == 'A' || pilihanPaket == 'a'){
     totalPaket=1200000;
    } else if(pilihanPaket == 'B' || pilihanPaket == 'b'){
     totalPaket=200000;
    } else if(pilihanPaket == 'C' || pilihanPaket == 'c'){
     totalPaket=5000000;
    } else if(pilihanPaket == 'D' || pilihanPaket == 'd'){
     totalPaket=2000000;
    } else if(pilihanPaket == 'E' || pilihanPaket == 'e'){
     totalPaket=150000;
	 
    } else {
     cout<<"Paket Tidak Tersedia"<<endl;
    }
    
    cout<<"Berapa Banyak Pesanan? ";
    cin>>banyak;
    
    totalSeluruhPesanan[x]=totalPaket*banyak;
    
    cout<<"Apakah Ada Pesanan Lainnya (Y/N)?";
    cin>>yesNo;
   break;
   
   case 3:
    cout<<"Perlengkapan Rumah"<<endl;
    cout<<endl;
    
    cout<<"A. Meja Belajar   : Rp.400.000,00"<<endl;
    cout<<"B. Lemari         : Rp.800.000,00"<<endl;
    cout<<"C. Kasur          : Rp.500.000,00"<<endl;
    cout<<"D. Rak Buku       : Rp.250.000,00"<<endl;
    cout<<"E. Rak Sepatu     : Rp.100.000,00"<<endl;
    
    cout<<"Masukkan Pilihan : ";
    cin>>pilihanPaket;;
    
    if(pilihanPaket == 'A' || pilihanPaket == 'a'){
     totalPaket=400000;
    } else if(pilihanPaket == 'B' || pilihanPaket == 'b'){
     totalPaket=800000;
    } else if(pilihanPaket == 'C' || pilihanPaket == 'c'){
     totalPaket=500000;
    } else if(pilihanPaket == 'D' || pilihanPaket == 'd'){
     totalPaket=250000;
	} else if(pilihanPaket == 'E' || pilihanPaket == 'e'){
	 totalPaket=100000;
	 
    } else {
     cout<<"Paket Tidak Tersedia"<<endl;
    }
    
    cout<<"Berapa Banyak Pesanan? ";
    cin>>banyak;
    
    totalSeluruhPesanan[x]=totalPaket*banyak;
    
    cout<<"Apakah Ada Pesanan Lainnya (Y/N)?";
    cin>>yesNo;
   
   break;
    
    case 4:
    cout<<"Sepatu Pria"<<endl;
    cout<<endl; 
    
    cout<<"A. Sneakers        : Rp.400.000,00"<<endl;
    cout<<"B. Slip-On         : Rp.250.000,00"<<endl;
    cout<<"C. Sepatu Formal   : Rp.360.000,00"<<endl;
    cout<<"D. Tali Sepatu     : Rp.15.000,00"<<endl;
    cout<<"E. Kaos Kaki       : Rp.20.000,00"<<endl;
    
    cout<<"Masukkan Pilihan Paket : ";
    cin>>pilihanPaket;
    
    if(pilihanPaket == 'A' || pilihanPaket == 'a'){
     totalPaket=400000;
    } else if(pilihanPaket == 'B' || pilihanPaket == 'b'){
     totalPaket=250000;
    } else if(pilihanPaket == 'C' || pilihanPaket == 'c'){
     totalPaket=360000;
    } else if(pilihanPaket == 'D' || pilihanPaket == 'd'){
     totalPaket=15000;
    } else if(pilihanPaket == 'E' || pilihanPaket == 'e'){
     totalPaket=20000;
	
    } else {
     cout<<"Paket Tidak Tersedia"<<endl;
    }
    
    cout<<"Berapa Banyak Pesanan? ";
    cin>>banyak;
    
    totalSeluruhPesanan[x]=totalPaket*banyak;
    
    cout<<"Apakah Ada Pesanan Lainnya (Y/N)?";
    cin>>yesNo;
   
   break; 
   
   case 5:
    cout<<"Fotografi"<<endl;
    cout<<endl;
    
    cout<<"A. Kamera          : Rp.13.000.000,00"<<endl;
    cout<<"B. lighting        : Rp.2.000.000,00"<<endl;
    cout<<"C. Printer Foto    : Rp.500.000,00"<<endl;
    cout<<"D. Lensa           : Rp.6.000.000,00"<<endl;
    cout<<"E. Tripod          : Rp.200.000,00"<<endl;
    
    cout<<"Masukkan Pilihan Paket : ";
    cin>>pilihanPaket;
    
    if(pilihanPaket == 'A' || pilihanPaket == 'a'){
     totalPaket=13000000;
    } else if(pilihanPaket == 'B' || pilihanPaket == 'b'){
     totalPaket=2000000;
    } else if(pilihanPaket == 'C' || pilihanPaket == 'c'){
     totalPaket=500000;
    } else if(pilihanPaket == 'D' || pilihanPaket == 'd'){
     totalPaket=6000000;
	} else if(pilihanPaket == 'E' || pilihanPaket == 'e'){
	 totalPaket=200000;
	 
    } else {
	
     cout<<"Paket Tidak Tersedia"<<endl;
    }
    
    cout<<"Berapa Banyak Pesanan? ";
    cin>>banyak;
    
    totalSeluruhPesanan[x]=totalPaket*banyak;
    
    cout<<"Apakah Ada Pesanan Lainnya (Y/N)?";
    cin>>yesNo;
   
   break; 
  }
  x++;
 } while(yesNo == 'Y' || yesNo == 'y');
 
 cout<<"Pembayaran : "<<endl;
 
 for(int i=0;i<x;i++){
  hasil=hasil+totalSeluruhPesanan[i];
 }
 
 cout<<"Total Pesanan : "<<hasil<<endl;
 cout<<"Diskon 10% : "<<hasil/diskon<<endl;
 cout<<"Total Bayar : "<<hasil - (hasil/diskon)<<endl;
}
